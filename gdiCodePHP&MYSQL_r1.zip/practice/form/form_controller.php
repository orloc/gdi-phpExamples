<?php


//Check to see if the request is a POST

// Grab the data out of the $_POST super global

// Write it to a file
